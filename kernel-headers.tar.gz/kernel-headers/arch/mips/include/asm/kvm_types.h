/* SPDX-License-Identifier: GPL-2.0 */
#ifndef _ASM_MIPS_KVM_TYPES_H
#define _ASM_MIPS_KVM_TYPES_H

#define KVM_ARCH_NR_OBJS_PER_MEMORY_CACHE     4

#endif /* _ASM_MIPS_KVM_TYPES_H */
