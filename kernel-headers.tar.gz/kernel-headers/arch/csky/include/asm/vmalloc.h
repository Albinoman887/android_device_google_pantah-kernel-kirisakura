#ifndef _ASM_CSKY_VMALLOC_H
#define _ASM_CSKY_VMALLOC_H

#endif /* _ASM_CSKY_VMALLOC_H */
