/* SPDX-License-Identifier: GPL-2.0 */
// Copyright (C) 2018 Hangzhou C-SKY Microsystems co.,ltd.

#ifndef _CSKY_STRING_MM_H_
#define _CSKY_STRING_MM_H_

#ifndef __ASSEMBLY__
#include <linux/types.h>
#include <linux/compiler.h>
#include <abi/string.h>
#endif

#endif /* _CSKY_STRING_MM_H_ */
