#ifndef _ASM_C6X_VMALLOC_H
#define _ASM_C6X_VMALLOC_H

#endif /* _ASM_C6X_VMALLOC_H */
