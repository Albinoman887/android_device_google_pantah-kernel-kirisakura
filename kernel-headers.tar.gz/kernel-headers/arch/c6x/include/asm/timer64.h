/* SPDX-License-Identifier: GPL-2.0 */
#ifndef _C6X_TIMER64_H
#define _C6X_TIMER64_H

extern void __init timer64_init(void);

#endif /* _C6X_TIMER64_H */
