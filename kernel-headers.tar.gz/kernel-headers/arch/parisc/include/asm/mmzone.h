/* SPDX-License-Identifier: GPL-2.0 */
#ifndef _PARISC_MMZONE_H
#define _PARISC_MMZONE_H

#define MAX_PHYSMEM_RANGES 4 /* Fix the size for now (current known max is 3) */

#endif /* _PARISC_MMZONE_H */
